__version__ = "0.47.0+hal.realtime.1"
